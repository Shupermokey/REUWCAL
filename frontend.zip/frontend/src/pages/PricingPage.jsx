import React from 'react'
import Sidebar from '../components/Sidebar'

function PricingPage() {
  return (
    <div>
            <Sidebar/>
            <div>Pricing</div>
    </div>
  )
}

export default PricingPage