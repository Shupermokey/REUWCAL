import React from 'react'
import Sidebar from '../components/Sidebar'

function DashboardPage() {
  return (
    <div>
            <Sidebar/>
            <div>Dashboard</div>
    </div>
  )
}

export default DashboardPage