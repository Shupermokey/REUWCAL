import React from "react";

const DeveloperTools = () => {
  return (
    <div style={{ padding: "2rem" }}>
      <h1>👨‍💻 Developer Tools</h1>
      <p>This page is only available to users with Developer or Syndicator tiers.</p>
    </div>
  );
};

export default DeveloperTools;
